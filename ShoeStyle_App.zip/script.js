const products = [
  { id: 1, name: "Everyday Loafer", gender: "men", category: "casual", price: 28000, emoji: "👞", color: "#e8e0d4", label: "Everyday" },
  { id: 2, name: "Street Runner", gender: "men", category: "sneakers", price: 42000, emoji: "👟", color: "#dfe8ff", label: "Popular" },
  { id: 3, name: "Classic Flat", gender: "women", category: "flats", price: 24000, emoji: "🥿", color: "#ffe7ef", label: "Comfort" },
  { id: 4, name: "City Sneaker", gender: "women", category: "sneakers", price: 39000, emoji: "👟", color: "#e4f5ed", label: "New" },
  { id: 5, name: "Weekend Slip-on", gender: "men", category: "casual", price: 32000, emoji: "👟", color: "#f4ead9", label: "Easy wear" },
  { id: 6, name: "Ballet Flat", gender: "women", category: "flats", price: 22000, emoji: "🥿", color: "#f5e4dc", label: "Lightweight" },
  { id: 7, name: "Court Sneakers", gender: "men", category: "sneakers", price: 45000, emoji: "👟", color: "#e8e8f5", label: "Classic" },
  { id: 8, name: "Smart Casual Heel", gender: "women", category: "casual", price: 35000, emoji: "👠", color: "#f7e2e8", label: "Dress up" },
  { id: 9, name: "Minimalist Loafer", gender: "women", category: "casual", price: 30000, emoji: "👞", color: "#e7e4dc", label: "Versatile" },
  { id: 10, name: "Daily Comfort Flat", gender: "men", category: "flats", price: 26000, emoji: "🥿", color: "#e3eff5", label: "Comfort" },
  { id: 11, name: "Cloud Walk Sneaker", gender: "women", category: "sneakers", price: 41000, emoji: "👟", color: "#e6eaff", label: "Soft step" },
  { id: 12, name: "Office Slip-on", gender: "men", category: "flats", price: 27000, emoji: "👞", color: "#e9e2d9", label: "Workwear" }
];

const genderFilter = document.getElementById("genderFilter");
const categoryFilter = document.getElementById("categoryFilter");
const searchInput = document.getElementById("searchInput");
const productGrid = document.getElementById("productGrid");
const resultCount = document.getElementById("resultCount");
const emptyState = document.getElementById("emptyState");
const cartCount = document.getElementById("cartCount");
const cartButton = document.getElementById("cartButton");
const resetFilters = document.getElementById("resetFilters");
const toast = document.getElementById("toast");

let cart = 0;
let toastTimer;

function formatPrice(price) {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0
  }).format(price);
}

function renderProducts() {
  const gender = genderFilter.value;
  const category = categoryFilter.value;
  const query = searchInput.value.trim().toLowerCase();

  const filtered = products.filter(product => {
    const matchesGender = gender === "all" || product.gender === gender;
    const matchesCategory = category === "all" || product.category === category;
    const matchesSearch = `${product.name} ${product.gender} ${product.category}`
      .toLowerCase().includes(query);
    return matchesGender && matchesCategory && matchesSearch;
  });

  productGrid.replaceChildren();
  resultCount.textContent = `Showing ${filtered.length} ${filtered.length === 1 ? "shoe" : "shoes"}`;
  emptyState.hidden = filtered.length > 0;

  filtered.forEach(product => {
    const card = document.createElement("article");
    card.className = "product-card";

    const visual = document.createElement("div");
    visual.className = "product-visual";
    visual.style.setProperty("--visual-bg", product.color);

    const badge = document.createElement("span");
    badge.className = "product-badge";
    badge.textContent = product.label;

    const emoji = document.createElement("span");
    emoji.className = "product-emoji";
    emoji.textContent = product.emoji;
    emoji.setAttribute("aria-hidden", "true");

    visual.append(badge, emoji);

    const details = document.createElement("div");
    details.className = "product-details";

    const type = document.createElement("p");
    type.className = "product-type";
    type.textContent = `${product.gender} · ${product.category}`;

    const name = document.createElement("h3");
    name.textContent = product.name;

    const meta = document.createElement("p");
    meta.className = "product-meta";
    meta.textContent = "Sample product · Choose size with seller";

    const bottom = document.createElement("div");
    bottom.className = "product-bottom";

    const price = document.createElement("span");
    price.className = "price";
    price.textContent = formatPrice(product.price);

    const addButton = document.createElement("button");
    addButton.className = "add-button";
    addButton.type = "button";
    addButton.textContent = "Add to bag";
    addButton.addEventListener("click", () => {
      cart += 1;
      cartCount.textContent = cart;
      showToast(`${product.name} added to your bag`);
    });

    bottom.append(price, addButton);
    details.append(type, name, meta, bottom);
    card.append(visual, details);
    productGrid.append(card);
  });
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

genderFilter.addEventListener("change", renderProducts);
categoryFilter.addEventListener("change", renderProducts);
searchInput.addEventListener("input", renderProducts);

resetFilters.addEventListener("click", () => {
  genderFilter.value = "all";
  categoryFilter.value = "all";
  searchInput.value = "";
  renderProducts();
});

cartButton.addEventListener("click", () => {
  showToast(`Your bag contains ${cart} ${cart === 1 ? "item" : "items"}`);
});

renderProducts();
